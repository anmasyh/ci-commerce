<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_account extends CI_Model {
    public function register($data)
    {
        $this->db->insert('tbl_pelanggan', $data);
        
    }
    

}