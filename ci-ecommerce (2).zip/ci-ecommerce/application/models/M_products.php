<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_products extends CI_Model
{
    public function get_all_data()
    {
        $this->db->select('*');
        $this->db->from('tbl_produk');
        $this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_produk.id_kategori', 'left');
        $this->db->order_by('id_produk', 'esc');
        return $this->db->get()->result();
    }

    
    public function product_details($id_produk)
    {
        $this->db->select('*');
        $this->db->from('tbl_produk');
        $this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_produk.id_kategori', 'left');
        $this->db->where('id_produk', $id_produk);
        return $this->db->get()->row();
    }

    public function find($id_produk)
    {
        $result = $this->db->where('id_produk', $id_produk)
        ->limit(1)
        ->get('tbl_produk');
        if ($result->num_rows()>0) {
            return $result->row();
        }else{
            return array();
        }
        
    }

}