<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_admin extends CI_Model {

    public function total_produk()
    {
        return $this->db->get('tbl_produk')->num_rows();
    }

    public function jml_user()
    {
        return $this->db->get('tbl_user')->num_rows();
    }
}