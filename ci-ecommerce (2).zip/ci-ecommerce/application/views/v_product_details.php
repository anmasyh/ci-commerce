<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <link rel="stylesheet" href="<?= base_url() ?>template/dist/css/style.css">
    <link rel="stylesheet" href="<?= base_url() ?>template/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>


    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="<?= base_url() ?>">
                    <img src="http://localhost/ecommerce/ci-ecommerce/assets/logo1.png" width="125px">
                </a>
            </div>

            <nav>
                <ul id="MenuItems">
                    <li><a href="<?= base_url() ?>">Home</a></li>
                    <li><a href="<?= base_url('products') ?>">Products</a></li>
                    <li>
                    <?php $kategori = $this->m_home->get_all_data_kategori(); ?>
                        <div class="dropdown">
                            <span>Category <i class="fa fa-chevron-down"></i></span>
                            <div class="dropdown-content">
                                <ul>
                                    <?php foreach ($kategori as $key => $value) { ?>
                                    <li><a href="<?= base_url('home/category/' . $value->id_kategori) ?>"><?= $value->nama_kategori ?></a></li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li><a href="">Contact</a></li>
                    <li><a href="">Account</a></li>
                </ul>
            </nav>
                <a href="<?= base_url('cart') ?>"><img src="http://localhost/ecommerce/ci-ecommerce/assets/cart.png" width="30px" height="30px"></a>
                <div class="badge">  
                <?php 
                $keranjang = $this->cart->total_items();
                ?>
                <span><?php echo $keranjang ?></span>
                </div>
            <img src="http://localhost/ecommerce/ci-ecommerce/assets/menu.png" class="menu-icon" onclick="menutoggle()">
        </div>
    </div>

    <div class="small-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="<?= base_url('assets/gambar/' . $produk->gambar)?>" width="90%">
            </div>
            <div class="col-2">
                <p>Category : <?= $produk->nama_kategori ?></p>
                <h1><?= $produk->nama_produk ?></h1>
                <h3>IDR <?= number_format ($produk->harga, 0) ?></h3>
                <p>Stok : <?= $produk->stok ?></p>

                <form method="post" action="<?php echo base_url('cart/add') ?>" accept-charset="utf-8">
                <input type="hidden" name="id" value="<?php echo $produk->id_produk ?>" />
                <input type="hidden" name="name" value="<?php echo $produk->nama_produk ?>" />
                <input type="hidden" name="price" value="<?php echo $produk->harga ?>" />
                <input type="hidden" name="gambar" value="<?php echo $produk->gambar ?>" />
                <input type="hidden" name="stok" value="<?php echo $produk->stok ?>" />

                <input type="number" name="qty" class="form-control" value="1" min="1" max="<?= $produk->stok ?>">

                <button class="btn swalDefaultSuccess">Add to Cart</button>
                </form>
                <h2><?= $title ?> <i class="fa fa-indent"></i></h2>
                <br>
                <p><?= $produk->deskripsi ?></p>
                
            </div>
        </div>
    </div>

    <div class="small-container">
        <div class="row row-2">
            <h2>Related Products</h2>
            <p>View More</p>
        </div>
    </div>

    <div class="small-container">
        <div class="row">
            <div class="col-4">
                <img src="images/product-1.jpg">
                <h4>Triple Band Solitaire 3.6gr/17K</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>IDR 8.499.000,-</p>
            </div>

            <div class="col-4">
                <img src="images/product-2.jpg">
                <h4>Gold Bracelet 3.3gr/17K</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>IDR 8.499.000,-</p>
            </div>

            <div class="col-4">
                <img src="images/product-3.jpg">
                <h4>Gold Earrings 3.5gr/17K</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>IDR 8.499.000,-</p>
            </div>

            <div class="col-4">
                <img src="images/product-4.jpg">
                <h4>Rose Necklace 10.75gr/17K</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>IDR 8.499.000,-</p>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                    <h3>Toko Mas Tosca Pati</h3>
                    <div class="app-logo">
                        <img src="http://localhost/ecommerce/ci-ecommerce/assets/logo-footer.jpg">
                    </div>
                </div>

                <div class="footer-col-2">
                    <p><i class="fa fa-map-marker fa-fw"></i> Jl. Pemuda No.272, Pati Wetan, Kec. Pati, Kabupaten Pati, Jawa Tengah 59119</p>
                    <p><i class="fa fa-clock-o fa-fw"></i> Senin - Sabtu 08:30 - 05:00 WIB</p>
                    <p><i class="fa fa-phone fa-fw"></i> (0295) 381658</p>
                </div>

                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li><a href="#">Tentang Kami</a></li>
                        <li><a href="#">Kontak Kami</a></li>
                    </ul>
                </div>

                <div class="footer-col-4">
                    <h3>FAQ</h3>
                    <ul>
                        <li><a href="#">Panduan Ukuran</a></li>
                        <li><a href="#">Panduan Belanja</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <p class="copyright">Copyright 2021 - Toko Mas Tosca Pati</p>
        </div>
    </div>

    <script>
        var MenuItems = document.getElementById("MenuItems");

        MenuItems.style.maxHeight = "0px";

        function menutoggle() {
            if (MenuItems.style.maxHeight == "0px") {
                MenuItems.style.maxHeight = "200px";
            } else {
                MenuItems.style.maxHeight = "0px";
            }

        }
    </script>

<script src="<?= base_url() ?>template/plugins/jquery/jquery.min.js"></script>
<script src="<?= base_url() ?>template/plugins/sweetalert2/sweetalert2.min.js"></script>
    <script type="text/javascript">
        $(function() {
            const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3500
    });

    $('.swalDefaultSuccess').click(function() {
      Toast.fire({
        icon: 'success',
        title: 'Success! Berhasil Menambahkan Produk ke Keranjang.'
        })
        });
    });
</script>

</body>

</html>