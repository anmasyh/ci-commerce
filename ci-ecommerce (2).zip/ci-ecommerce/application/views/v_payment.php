<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="<?= base_url() ?>template/dist/css/style.css">
    <link rel="stylesheet" href="<?= base_url() ?>template/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>


    <div class="container">
    <div class="navbar">
                <div class="logo">
                    <a href="<?= base_url() ?>"><img src="<?= base_url() ?>assets/logo1.png" width="125px"></a>
                </div>

                <nav>
                    <ul id="MenuItems">
                        <li><a href="<?= base_url() ?>">Home</a></li>
                        <li><a href="<?= base_url('products') ?>">Products</a></li>
                        <li>
                        <?php $kategori = $this->m_home->get_all_data_kategori(); ?>
                        <div class="dropdown">
                            <span>Category <i class="fa fa-chevron-down"></i></span>
                            <div class="dropdown-content">
                                <ul>
                                    <?php foreach ($kategori as $key => $value) { ?>
                                    <li><a href="<?= base_url('home/category/' . $value->id_kategori) ?>"><?= $value->nama_kategori ?></a></li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                        </li>
                        <li><a href="">Contact</a></li>
                        <li><a href="">Account</a></li>
                    </ul>
                </nav>
                <a href="<?= base_url('cart') ?>"><img src="<?= base_url() ?>assets/cart.png" width="30px" height="30px"></a>
                <div class="badge">
                <?php 
                $keranjang = $this->cart->total_items();
                ?>
                <span><?php echo $keranjang ?></span>
                </div>
                <img src="<?= base_url() ?>assets/menu.png" class="menu-icon" onclick="menutoggle()">
            </div>
    </div>
<br>
    <div class="small-container form">
    <form action="">
    <h2>Alamat Pengiriman</h2>
    <input type="text" placeholder="Nama Lengkap"><br>
    <input type="text" id="lname" name="lname" value="Doe"><br><br>
    </form> 
    </div>
    
    <div class="small-container shipping-page">
        <table>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
            <?php
            foreach ($this->cart->contents() as $items) :  ?>
            <tr>
                <td>
                    <div class="cart-info">
                        <img src="<?php echo base_url('assets/gambar/');?><?php echo $items['gambar'] ?>">
                        <div>
                            <p><?php echo $items ['name'] ?></p>
                            <small>IDR <?php echo number_format($items['price'], 0, ',','.') ?></small>
                            
                        </div>
                    </div>
                </td>
                <td><input type="number" value="<?php echo $items ['qty'] ?>" min="<?php echo $items ['qty'] ?>" max="<?php echo $items ['qty'] ?>"></td>
                <td>IDR <?php echo number_format($items['subtotal'], 0, ',','.') ?></td>
            </tr>
            <?php endforeach; ?>
        </table>

        <div class="total-price">
            <table>
                <tr>
                    <td>Total</td>
                    <td>IDR <?php echo number_format($this->cart->total(), 0, ',','.') ?></td>
                </tr>
            </table>
        </div>
        
        <div class="cart">  
            <a href="<?= base_url('cart/payment') ?>"><div class="btn btn-continue">Check Out <i class="fa fa-chevron-right"></i></div></a>
        </div>
        <br><br><br><br>
    </div>

    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                    <h3>Toko Mas Tosca Pati</h3>
                    <div class="app-logo">
                        <img src="<?= base_url() ?>assets/logo-footer.jpg">
                    </div>
                </div>

                <div class="footer-col-2">
                    <p><i class="fa fa-map-marker fa-fw"></i> Jl. Pemuda No.272, Pati Wetan, Kec. Pati, Kabupaten Pati, Jawa Tengah 59119</p>
                    <p><i class="fa fa-clock-o fa-fw"></i> Senin - Sabtu 08:30 - 05:00 WIB</p>
                    <p><i class="fa fa-phone fa-fw"></i> (0295) 381658</p>
                </div>

                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li><a href="#">Tentang Kami</a></li>
                        <li><a href="#">Kontak Kami</a></li>
                    </ul>
                </div>

                <div class="footer-col-4">
                    <h3>FAQ</h3>
                    <ul>
                        <li><a href="#">Panduan Ukuran</a></li>
                        <li><a href="#">Panduan Belanja</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <p class="copyright">Copyright 2021 - Toko Mas Tosca Pati</p>
        </div>
    </div>

    <script>
        var MenuItems = document.getElementById("MenuItems");

        MenuItems.style.maxHeight = "0px";

        function menutoggle() {
            if (MenuItems.style.maxHeight == "0px") {
                MenuItems.style.maxHeight = "200px";
            } else {
                MenuItems.style.maxHeight = "0px";
            }

        }
    </script>

</body>

</html>