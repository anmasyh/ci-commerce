<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products - Toko Mas Tosca Pati</title>
    <link rel="stylesheet" href="<?= base_url() ?>template/dist/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>


    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="<?= base_url() ?>"><img src="http://localhost/ecommerce/ci-ecommerce/assets/logo1.png" width="125px"></a>
            </div>

            <nav>
                <ul id="MenuItems">
                    <li><a href="<?= base_url() ?>">Home</a></li>
                    <li><a href="<?= base_url('products') ?>">Products</a></li>
                    <li>
                    <?php $kategori = $this->m_home->get_all_data_kategori(); ?>
                        <div class="dropdown">
                            <span>Category <i class="fa fa-chevron-down"></i></span>
                            <div class="dropdown-content">
                                <ul>
                                    <?php foreach ($kategori as $key => $value) { ?>
                                    <li><a href="<?= base_url('home/category/' . $value->id_kategori) ?>"><?= $value->nama_kategori ?></a></li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li><a href="">Contact</a></li>
                    <li><a href="">Account</a></li>
                </ul>
            </nav>
            <img src="http://localhost/ecommerce/ci-ecommerce/assets/cart.png" width="30px" height="30px">
            <img src="http://localhost/ecommerce/ci-ecommerce/assets/menu.png" class="menu-icon" onclick="menutoggle()">
        </div>
    </div>


    <div class="small-container">
        
        <div class="row row-2">
            <h2><?= $title ?></h2>
            <select>
                <option>Default Shorting</option>
                <option>Short by price</option>
                <option>Short by popularity</option>
                <option>Short by rating</option>
                <option>Short by sale</option>
            </select>
        </div>

        <div class="row">

            <?php foreach ($produk as $key => $value) { ?>

            <div class="col-4">
                <a href="<?= base_url('products/product_details/' . $value->id_produk)?>">
                <img src="<?= base_url('assets/gambar/' . $value->gambar)?>">
                <h4><?= $value->nama_produk ?></h4>
                </a>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>IDR <?= number_format ($value->harga, 0) ?></p>
            </div>
        
            <?php } ?>
        
        </div>

        <div class="page-btn">
            <span>1</span>
            <span>2</span>
            <span>3</span>
            <span>4</span>
            <span>&#8594;</span>
        </div>

    </div>

    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                    <h3>Toko Mas Tosca Pati</h3>
                    <div class="app-logo">
                        <img src="http://localhost/ecommerce/ci-ecommerce/assets/logo-footer.jpg">
                    </div>
                </div>

                <div class="footer-col-2">
                    <p><i class="fa fa-map-marker fa-fw"></i> Jl. Pemuda No.272, Pati Wetan, Kec. Pati, Kabupaten Pati, Jawa Tengah 59119</p>
                    <p><i class="fa fa-clock-o fa-fw"></i> Senin - Sabtu 08:30 - 05:00 WIB</p>
                    <p><i class="fa fa-phone fa-fw"></i> (0295) 381658</p>
                </div>

                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li><a href="#">Tentang Kami</a></li>
                        <li><a href="#">Kontak Kami</a></li>
                    </ul>
                </div>

                <div class="footer-col-4">
                    <h3>FAQ</h3>
                    <ul>
                        <li><a href="#">Panduan Ukuran</a></li>
                        <li><a href="#">Panduan Belanja</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <p class="copyright">Copyright 2021 - Toko Mas Tosca Pati</p>
        </div>
    </div>

    <script>
        var MenuItems = document.getElementById("MenuItems");

        MenuItems.style.maxHeight = "0px";

        function menutoggle() {
            if (MenuItems.style.maxHeight == "0px") {
                MenuItems.style.maxHeight = "200px";
            } else {
                MenuItems.style.maxHeight = "0px";
            }

        }
    </script>

</body>

</html>