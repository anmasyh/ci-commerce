<div class="col-md-12">
  <div class="card card-primary">
    <div class="card-header">
      <h3 class="card-title"><b><i>Data Produk Toko Mas Tosca</i></b></h3>

      <div class="card-tools">
        <a href="<?= base_url('produk/add')?>" type="button" class="btn btn-primary btn-sm"><i class="fas fa-plus-circle fa-lg"></i></a>
      </div>
      <!-- /.card-tools -->
    </div>
    <!-- /.card-header -->
    <div class="card-body">

        <?php
          if ($this->session->flashdata('pesan')) {
            echo '<div class="alert alert-success alert-dismissible"> <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> <h5><i class="icon fas fa-check"></i>';
            echo $this->session->flashdata('pesan');
            echo '</h5></div>';
          }
        ?>

      <table class="table table-bordered" id="example1">
        <thead class="text-center">
          <tr>
            <th>No</th>
            <th>Nama Produk</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Gambar</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1;
          foreach ($produk as $key => $value) { ?>
            <tr>
              <td class="text-center"><?= $no++;?></td>
              <td><?= $value->nama_produk ?></td>
              <td class="text-center"><?= $value->nama_kategori ?></td>
              <td class="text-center">IDR <?= number_format ($value->harga, 0) ?></td>
              <td class="text-center"><?= $value->stok ?></td>
              <td class="text-center"><img src="<?= base_url('assets/gambar/' . $value->gambar)?>" width="150" alt=""></td>
              <td class="text-center">
                <a href="<?= base_url('produk/edit/' . $value->id_produk) ?>" class="btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                <button class="btn-danger btn-xs" data-toggle="modal" data-target="#delete<?= $value->id_produk?>"><i class="fas fa-trash-alt"></i></button>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>

<!-- /.modal delete-->
<?php
  foreach ($produk as $key => $value) { ?>
<div class="modal fade" id="delete<?= $value->id_produk?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title">Anda Akan Menghapus <?= $value->nama_produk ?>!</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <h7>Apakah Anda Yakin?</h7>

      </div>
      <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <a href="<?= base_url('produk/delete/' . $value->id_produk) ?>" class="btn btn-danger">Hapus</a>
      </div>

    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div> 
<?php } ?>