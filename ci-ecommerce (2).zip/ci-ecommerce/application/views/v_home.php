<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jewelry Shop | Toko Mas Tosca Pati</title>
    <link rel="stylesheet" href="<?= base_url() ?>template/dist/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>

    <div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="<?= base_url() ?>"><img src="http://localhost/ecommerce/ci-ecommerce/assets/logo1.png" width="125px"></a>
                </div>

                <nav>
                    <ul id="MenuItems">
                        <li><a href="<?= base_url() ?>">Home</a></li>
                        <li><a href="<?= base_url('products') ?>">Products</a></li>
                        <li>
                        <?php $kategori = $this->m_home->get_all_data_kategori(); ?>
                        <div class="dropdown">
                            <span>Category <i class="fa fa-chevron-down"></i></span>
                            <div class="dropdown-content">
                                <ul>
                                    <?php foreach ($kategori as $key => $value) { ?>
                                    <li><a href="<?= base_url('home/category/' . $value->id_kategori) ?>"><?= $value->nama_kategori ?></a></li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                        </li>
                        <li><a href="">Contact</a></li>
                        <li><a href="<?= base_url('account') ?>">Account</a></li>
                    </ul>
                </nav>
                <a href="<?= base_url('cart') ?>"><img src="http://localhost/ecommerce/ci-ecommerce/assets/cart.png" width="30px" height="30px"></a>
                <div class="badge">
                <?php 
                $keranjang = $this->cart->total_items();
                ?>
                <span><?php echo $keranjang ?></span>
                </div>
                <img src="http://localhost/ecommerce/ci-ecommerce/assets/menu.png" class="menu-icon" onclick="menutoggle()">
            </div>

            <div class="row">
                <div class="col-2">
                    <h1>Everyday<br> Fine Jewelry!</h1>
                    <p>Tosca Mas jewelry is crafted with the highest quality precious<br>metals and gemstones so you can be certain of its quality.</p>
                    <a href="<?= base_url('products') ?>" class="btn">Explore Now <i class="fa-fw fa fa-long-arrow-right"></i></a>
                </div>

                <div class="col-2">
                    <img src="<?= base_url() ?>/assets/header.png">
                </div>
            </div>
        </div>
</div>

    <div class="small-container">
        <h2 class="title">Featured Products</h2>
        <div class="row">
        <?php foreach ($produk as $key => $value) { ?>
            <div class="col-4">
                
                <a href="<?= base_url('products/product_details/' . $value->id_produk)?>">
                <img src="<?= base_url('assets/gambar/' . $value->gambar)?>">
                <h4><?= $value->nama_produk ?></h4>
                </a>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>IDR <?= number_format ($value->harga, 0) ?></p>
            </div>
            <?php } ?>
        </div>
    </div>

        
    
    <div class="small-container">
        <h2 class="title">Latest Products</h2>
        <div class="row">
        <?php foreach ($produk as $key => $value) { ?>
            <div class="col-4">
                
                <a href="<?= base_url('products/product_details/' . $value->id_produk)?>">
                <img src="<?= base_url('assets/gambar/' . $value->gambar)?>">
                <h4><?= $value->nama_produk ?></h4>
                </a>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>IDR <?= number_format ($value->harga, 0) ?></p>

            </div>
            <?php } ?>            
        </div>
    </div>

    <div class="offer">
            <div class="small-container">
                <div class="row">
                    <div class="col-2">
                        <img src="http://localhost/ecommerce/ci-ecommerce/assets/promo.png" class="offer-img">
                    </div>
                    <div class="col-2">
                        <h1>BEAUTY LIKE NO OTHER.</h1>
                        <br>
                        <h2>CUSTOM JEWELRY DESIGN</h2>
                        <br>
                        <p>Have you dreamed of designing your own jewelry? We have custom jewelry designers that will transform your idea into reality.</p>
                        <br>
                        <a href="" class="btn">Find Out <i class="fa-fw fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    
    <div class="row">
        <a href="<?= base_url('products') ?>">
            <h2 class="title">All Products <i class="fa fa-angle-double-right"></i></h2>
        </a>
    </div>

    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                    <h3>Toko Mas Tosca Pati</h3>
                    <div class="app-logo">
                        <img src="<?= base_url() ?>/assets/logo-footer.jpg" title="Home">
                    </div>
                </div>

                <div class="footer-col-2">
                    <p><i class="fa fa-map-marker fa-fw"></i> Jl. Pemuda No.272, Pati Wetan, Kec. Pati, Kabupaten Pati, Jawa Tengah 59119</p>
                    <p><i class="fa fa-clock-o fa-fw"></i> Senin - Sabtu 08:30 - 05:00 WIB</p>
                    <p><i class="fa fa-phone fa-fw"></i> (0295) 381658</p>
                </div>

                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li><a href="#">Tentang Kami</a></li>
                        <li><a href="#">Kontak Kami</a></li>
                    </ul>
                </div>

                <div class="footer-col-4">
                    <h3>FAQ</h3>
                    <ul>
                        <li><a href="#">Panduan Ukuran</a></li>
                        <li><a href="#">Panduan Belanja</a></li>
                    </ul>
                </div>
            </div>
            <hr>
            <p class="copyright">Copyright 2021 - Toko Mas Tosca Pati</p>
        </div>
</div>

<script>
        var MenuItems = document.getElementById("MenuItems");

        MenuItems.style.maxHeight = "0px";

        function menutoggle() {
            if (MenuItems.style.maxHeight == "0px") {
                MenuItems.style.maxHeight = "200px";
            } else {
                MenuItems.style.maxHeight = "0px";
            }

        }
    </script>

</body>

</html>